import { sendMessageWithMention } from "../lib/utils.js";

async function handle(sock, messageInfo) {

  const { remoteJid, message, sender, senderType } = messageInfo;

  const priceText = `
..    ▓⃞💰 *𝗣𝗥𝗜𝗖𝗘𝗟𝗜𝗦𝗧 𝗟𝗔𝗬𝗔𝗡𝗔𝗡 𝗕𝗢𝗧*
.𖤓 ✦. *𝗟𝗜𝗠𝗜T*
ㅤㅤㅤ .. 📌
ㅤ    *· ✦ 🖇꯭ ׁ 100 : Rp.1.000*
ㅤ    *· ✦ 🖇꯭ ׁ 1.000 : Rp.5.000*
ㅤ    *· ✦ 🖇꯭ ׁ 5.000 : Rp.15.000*
✦. *𝗠𝗢𝗡𝗘𝗬*
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1.000* :   *Rp.1.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *10.000* :   *Rp.5.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *15.000* :   *Rp.10.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *25.000* :   *Rp.15.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *35.000* :   *Rp.25.000*
✦.  𝗣𝗥𝗘𝗠𝗨𝗦𝗘𝗥
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Hari*   :   *Rp.200*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *3 Hari*   :   *Rp.600*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Minggu*   :   *Rp.1.400*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Bulan*   :   *Rp.4.400*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *PERMANEN*   :   *Rp.20.000*
✦. *PAID GC*
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 hari* : *Rp.500*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *3 hari* : *Rp.1000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *7 hari* : *Rp.2000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *10 hari* : *Rp.3000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *30 hari* : *Rp.5000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *90 hari* : *Rp.10.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *permanen* : *Rp.30.000*
✦. *𝗦𝗘𝗪𝗔 𝗕𝗢𝗧 (𝗚𝗥𝗢𝗨𝗣)*
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Reguler*
         ·  ✦ㅤ🖇꯭  ׁ  *1 hari* : *Rp.300*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Minggu* :   *Rp.2.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Bulan* :   *Rp.7.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *PERMANEN* :   *Rp.25.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Premium*
         ·  ✦ㅤ🖇꯭  ׁ  *1 hari* : *Rp.1000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Minggu* :   *Rp.5.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Bulan* :   *Rp.15.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *PERMANEN* :   *Rp.50.000*
✦. *ONLY RVO*
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Reguler*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *​5x RVO* : *Rp.400*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *​10x RVO* : *Rp.500*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *​15x RVO* : *Rp.800*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *​20x RVO* : *Rp.1.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *​25x RVO* : *Rp.1.200*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *PERMANEN* : *Rp.10.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Premium (Nyala 24 Jam)*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *​5x RVO* : *Rp.1.200*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *​10x RVO* : *Rp.1.500*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *​15x RVO* : *Rp.2.400*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *​20x RVO* : *Rp.3.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *​25x RVO* : *Rp.3.600*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *PERMANEN* : *Rp.30.000*
✦. *OWNER (INCLUDE JADIBOT)*
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Minggu* :   *Rp.5.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Bulan* :   *Rp.15.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Permanen* :   *Rp.40.000*
​✦. 𝗕𝗜𝗞𝗜𝗡 𝗕𝗢𝗧 (𝗙𝗨𝗟𝗟 𝗙𝗜𝗧𝗨𝗥)
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Minggu* :   *Rp.7.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Bulan* :   *Rp.20.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Permanen* :   *Rp.50.000*
✦. *𝗟𝗜𝗠𝗜𝗧 𝗕𝗜𝗞𝗜𝗡 𝗕𝗢𝗧*
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1.000 Limit* : *Rp.5.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *2.000 Limit* : *Rp.8.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *5.000 Limit* : *Rp.16.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *10.000 Limit* : *Rp.25.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *20.000 Limit* : *Rp.40.000*
✦. *JASA*
ㅤ    *· ✦ 🖇꯭ ׁ hias pricelist teks* : *2.000*
ㅤ    *· ✦ 🖇꯭ ׁ hias qr : START Rp.5.000*
✦. *NOKOS*
ㅤㅤㅤ .. 📌
ㅤ    *· ✦ 🖇꯭ ׁ INDO : Rp.5.000*
ㅤ    *· ✦ 🖇꯭ ׁ LUAR : Rp.7.000 (TERGANTUNG NEGARA)*
​✦. 𝗖𝗨𝗦𝗧𝗢𝗠 𝗙𝗜𝗧𝗨𝗥
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Harga* : *Menyesuaikan kesulitan*
✦. *𝗣𝗔𝗡𝗘𝗟 (𝗣𝗧𝗘𝗥𝗢𝗗𝗔𝗖𝗧𝗬𝗟)*
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Ram 1GB* :   *Rp.1.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Ram 2GB* :   *Rp.2.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Ram 4GB* :   *Rp.4.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Ram Unlimited* : *Rp.10.000*
_(Silahkan hubungi owner untuk cek stok)_

*─── [ INFORMASI ] ───*

- Ingin beli? Ketik *.qris [nominal]*

- Butuh bantuan? Ketik *.owner*

- Semua transaksi *No Refund*.

_Hai @${sender.split("@")[0]}, harga di atas dapat berubah sewaktu-waktu._

`;

  await sendMessageWithMention(

    sock,

    remoteJid,

    priceText.trim(),

    message,

    senderType

  );

}

export default {

  handle,

  Commands: ["pricelist", "harga", "price"  , "pl"],

  OnlyPremium: false,

  OnlyOwner: false,

};
