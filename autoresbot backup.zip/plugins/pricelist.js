import { sendMessageWithMention } from "../lib/utils.js";

async function handle(sock, messageInfo) {

  const { remoteJid, message, sender, senderType } = messageInfo;

  const priceText = `

..    ▓⃞💰 𝗣𝗥𝗜𝗖𝗘𝗟𝗜𝗦𝗧 𝗟𝗔𝗬𝗔𝗡𝗔𝗡 𝗕𝗢𝗧    
.𖤓 ✦. 𝗣𝗥𝗜𝗩𝗔𝗧𝗘 𝗥𝗘𝗚𝗨𝗟𝗘𝗥
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Hari*   :   *Rp.200*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *3 Hari*   :   *Rp.600*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Minggu*   :   *Rp.1.400*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Bulan*   :   *Rp.4.400*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *PERMANEN*   :   *Rp.10.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Garansi Card*   :   *20% Harga (30 hari)*

✦. *LIMIT*
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *50*   :   *Rp.500*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *400*   :   *Rp.2.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1000*   :   *Rp.3.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *3.500*   :   *Rp.5.000*

✦. *MONEY*
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1.000*   :   *Rp.100*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *10.000*   :   *Rp.500*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *15.000*   :   *Rp.1.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *25.000*   :   *Rp.3.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *35.000*   :   *Rp.5.000*


✦. 𝗣𝗥𝗘𝗠𝗨𝗦𝗘𝗥
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Hari*   :   *Rp.200*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *3 Hari*   :   *Rp.600*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Minggu*   :   *Rp.1.400*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Bulan*   :   *Rp.4.400*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *PERMANEN*   :   *Rp.20.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Garansi Card*   :   *20% Harga (30 hari)*


✦. 𝗣𝗥𝗜𝗩𝗔𝗧𝗘 𝗣𝗥𝗘𝗠𝗜𝗨𝗠
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Hari*   :   *Rp.300*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *3 Hari*   :   *Rp.900*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Minggu*   :   *Rp.2.200*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Bulan*   :   *Rp.8.800*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *PERMANEN*   :   *Rp.30.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Garansi Card*   :   *20% Harga (30 hari)*

✦. 𝗦𝗘𝗪𝗔 𝗕𝗢𝗧 (*GROUP*)
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Reguler*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Hari*   :   *Rp.1.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Minggu*   :   *Rp.7.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Bulan*   :   *Rp.10.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *PERMANEN*   :   *Rp.50.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Garansi Card*   :   *20% Harga (30 hari)*

ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Premium*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Hari*   :   *Rp.2.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Minggu*   :   *Rp.12.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Bulan*   :   *Rp.35.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *PERMANEN*   :   *Rp.100.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Garansi Card*   :   *20% Harga (30 hari)*

✦. 𝗝𝗔𝗗𝗜 𝗕𝗢𝗧 (𝗖𝗟𝗢𝗡𝗘) / 𝗢𝗪𝗡𝗘𝗥 𝗕𝗢𝗧
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *3 Hari*   :   *Rp.4.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Minggu*   :   *Rp.8.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Bulan*   :   *Rp.15.000*

✦. 𝗝𝗔𝗦𝗔 𝗣𝗨𝗦𝗛 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧/
      𝗜𝗞𝗟𝗔𝗡 𝗚𝗥𝗢𝗨𝗣 𝗖𝗛𝗔𝗧
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Stack 1 (1× post)*   :   *Rp.2.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Stack 2 (2× post)*   :   *Rp.3.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Stack 3 (3× post)*   :   *Rp.5.000*

✦. *PANEL* (𝗣𝗧𝗘𝗥𝗢𝗗𝗔𝗖𝗧𝗬𝗟) (~TERSEDIA~/TIDAK TERSEDIA)
ㅤㅤㅤ .. 📌
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Ram 1GB*   :   *Rp.1.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Ram 2GB*   :   *Rp.2.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Ram 4GB*   :   *Rp.3.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Ram 8GB*   :   *Rp.5.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *Ram Unlimited*   :   *Rp.15.000*
ㅤㅤ ·  ✦ㅤ🖇꯭  ׁ  *1 Garansi Card*   :   *20% Harga Panel (30 hari)*


_(Silahkan hubungi owner untuk cek stok)_

*─── [ INFORMASI ] ───*

- Ingin beli? Ketik *.qris [nominal]*

- Butuh bantuan? Ketik *.owner*

- Semua transaksi *No Refund*.

_Hai @${sender.split("@")[0]}, harga di atas dapat berubah sewaktu-waktu._

`;

  await sendMessageWithMention(

    sock,

    remoteJid,

    priceText.trim(),

    message,

    senderType

  );

}

export default {

  handle,

  Commands: ["pricelist", "harga", "price"  , "pl"],

  OnlyPremium: false,

  OnlyOwner: false,

};
